import java.util.Scanner;

public class Exercicio3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Retangulo areaAPreencher = new Retangulo();
        System.out.println("Informe a largura do chão que deseja calcular: ");
        float largura = scanner.nextFloat();
        areaAPreencher.setLargura(largura);
        System.out.println("Informe o comprimento do chão que deseja calcular: ");
        areaAPreencher.setComprimento(scanner.nextFloat());
        System.out.println("O tamanho do rodapé a ser coberto será de: " + areaAPreencher.calcularPerimetro());
        System.out.println("A área que você deverá cobrir é de: " + areaAPreencher.calcularArea());

        // Retangulo piso = new Retangulo();
        // System.out.println("Informe a largura do piso que você pretende usar: ");
        // piso.setLargura(scanner.nextFloat());
        // System.out.println("Informe o comprimento do piso que você pretende usar: ");
        // piso.setComprimento(scanner.nextFloat());

        scanner.close();
    }
}