class BichinhoVirtual {
    private String nome;
    /** Este campo representa uma porcentagem */
    private float fome;
    /** Este campo representa uma porcentagem */
    private float saude;
    private int idade;

    public String obterHumor() {
        if (fome < 10 && saude > 90)
            return "Calmo";
        else if (saude < 50)
            return "Doente";
        else if (fome > 80)
            return "Com Raiva";
        else if (saude < 100 && saude > 60)
            return "Com Sono";
        return "Alegre";
    }

    public void alterarNome(String novoNome) {
        this.nome = novoNome;
    }

    public String obterNome() {
        return this.nome;
    }

    public float obterFome() {
        return this.fome;
    }

    public float obterSaude() {
        return this.saude;
    }

    public int obterIdade() {
        return this.idade;
    }
}