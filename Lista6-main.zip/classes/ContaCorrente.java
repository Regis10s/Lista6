class ContaCorrente {
    private String nomeCorrentista;
    private String numeroConta;
    private double saldo;

    public ContaCorrente(String nomeCorrentista, String numeroConta) {
        this.nomeCorrentista = nomeCorrentista;
        this.numeroConta = numeroConta;
        this.saldo = 0;
    }

    public ContaCorrente(String nomeCorrentista, String numeroConta, double saldo) {
        this.nomeCorrentista = nomeCorrentista;
        this.numeroConta = numeroConta;
        this.saldo = saldo;
    }

    public void alterarNome(String novoNome) {
        if (novoNome.equals(""))
            throw new Error("O nome não pode ser vazio");
        if (novoNome.equals(this.nomeCorrentista))
            throw new Error("Este já é o nome cadastrado");
        this.nomeCorrentista = novoNome;
    }

    public void deposito(double valorDepositado) {
        if (valorDepositado < 0)
            throw new Error("Valor depositado não pode ser negativo");
        this.saldo += valorDepositado;
    }

    public String saque(double quantiaSaque) {
        if (quantiaSaque > this.saldo)
            return "Saldo insuficiente na conta";
        this.saldo -= quantiaSaque;
        return "Saque realizado";
    }
}