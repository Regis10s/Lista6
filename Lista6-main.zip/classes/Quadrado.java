class Quadrado {
    private double lado;

    public void mudarValorDoLado(double novoValor) {
        if (novoValor < 0)
            throw new Error("Valor do lado não pode ser negativo", null);
        this.lado = novoValor;
    }

    public double retornarValorDoLado() {
        return this.lado;
    }

    public double calcularArea() {
        return this.lado * this.lado;
    }
}