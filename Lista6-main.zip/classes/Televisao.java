class Televisao {
    private final int AUDIO_MINIMO = 0;
    private final int AUDIO_MAXIMO = 100;
    private float canalAtual;
    private int volumeAtual = this.AUDIO_MAXIMO / 2;

    public void aumentarVolume() {
        this.volumeAtual++;
    }

    public void irParaCanal(float numeroCanal) {
        this.canalAtual = numeroCanal;
    }

    public void diminuirVolume() {
        this.volumeAtual--;
    }

}