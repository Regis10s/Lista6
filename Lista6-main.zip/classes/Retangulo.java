class Retangulo {
    private double comprimento;
    private double largura;

    public void mudarValorDosLados(double comprimento, double largura) {
        setComprimento(comprimento);
        setLargura(largura);
    }

    public void setComprimento(double novComprimento) {
        this.comprimento = novComprimento;
    }

    public void setLargura(double novaLargura) {
        this.largura = novaLargura;
    }

    public double getComprimento() {
        return this.comprimento;
    }

    public double getLargura() {
        return this.largura;
    }

    public double calcularArea() {
        return this.comprimento * this.largura;
    }

    public double calcularPerimetro() {
        return 2 * this.comprimento + 2 * this.largura;
    }
}