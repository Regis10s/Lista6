class Pessoa {
    private String nome;
    private float idade;
    private float peso;
    private float altura;
    /**
     * Esta variaável define em quantos centímetros a pessoa cresce até atingir os
     * 21 anos de idade
     */
    private float crescimentoCentimetros = .5f;

    public Pessoa(String nome) {
        this.setNome(nome);
    }

    public void setValorCrescimento(float novoValor) {
        this.nome = nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void envelhecer(int anos) {
        this.idade += anos;
        if (this.idade < 21) {
            this.crescer(this.crescimentoCentimetros);
        }
    }

    public void engordar(float pesoGanho) {
        this.peso += pesoGanho;
    }

    public void emagrecer(float pesoPerdido) {
        this.peso -= pesoPerdido;
    }

    public void crescer(float centimetros) {
        this.altura += centimetros;
    }
}