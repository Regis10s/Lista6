public class Bola {
    private String cor;
    private double circunferencia;
    private String material;

    public void trocaCor(String novaCor) {
        this.cor = novaCor;
    }

    public void mostraCor() {
        System.out.println(this.cor);
    }
}